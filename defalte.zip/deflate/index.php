<!DOCTYPE html>
<html>
    <head>
        <title>jQuery</title>
        <script src="jquery.js"></script>
    </head>
    <body>
        
    </body>
</html>

